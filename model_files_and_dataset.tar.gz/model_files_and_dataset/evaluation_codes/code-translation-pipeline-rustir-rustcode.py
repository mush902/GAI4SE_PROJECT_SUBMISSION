import json
import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import os


def translate_code(input_text, model_path, max_length=2048):
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_path)
    
    inputs = tokenizer(input_text, return_tensors="pt", truncation=True, padding=True)
    
    with torch.no_grad():
        outputs = model.generate(
            inputs["input_ids"], 
            max_length=max_length, 
            num_beams=5, 
            early_stopping=True
        )
    
    generated_output = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    return generated_output


def translation_pipeline(rust_ir):
    # Stage 1: C Code to C IR
    
    # Stage 3: Rust IR to Rust Code
    print("Stage started \n")
    text3 = f"translate Rust IR to Rust code: {rust_ir}"
    rust_code = translate_code(
        text3, 
        model_path="rust_ir_translation_model_best"
    )
    print("Stage ended \n")
    
    return rust_code


def process_translation_batch(input_json_path, output_json_path):
    # Read random C codes
    with open(input_json_path, 'r') as f:
        rust_irs = json.load(f)
    
    # Translate each C code
    inference_rust_codes = []
    for i, rust_ir in enumerate(rust_irs):
        print(f"Processing entry {i+1}/{len(rust_irs)}")
        try:
            rust_code = translation_pipeline(rust_ir)
            inference_rust_codes.append(rust_code)
        except Exception as e:
            print(f"Error processing entry {i+1}: {e}")
            inference_rust_codes.append(None)
    
    # Save translated Rust codes
    with open(output_json_path, 'w') as f:
        json.dump(inference_rust_codes, f, indent=2)
    
    print(f"Translation complete. Results saved to {output_json_path}")


if __name__ == "__main__":
    process_translation_batch(
        input_json_path='random_rust_ir.json',
        output_json_path='inference_rust_code.json'
    )
