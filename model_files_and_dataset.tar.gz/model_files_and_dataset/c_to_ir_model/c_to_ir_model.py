import json
import torch
import numpy as np
from datasets import Dataset
from transformers import (
    T5ForConditionalGeneration,
    RobertaTokenizer,
    get_linear_schedule_with_warmup,
    set_seed
)
from torch.utils.data import DataLoader
from torch.nn.utils import clip_grad_norm_
from tqdm import tqdm
import wandb
from typing import Dict, List
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CodeTranslationDataset(torch.utils.data.Dataset):
    def __init__(self, data: List[Dict], tokenizer, max_length: int = 512):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length
        
        # Special tokens for code translation
        self.tokenizer.add_special_tokens({
            'additional_special_tokens': [
                '<func>', '</func>', '<ir>', '</ir>'
            ]
        })

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        
        # Format input with special tokens
        source_text = f"<func> {item['c_code']} </func>"
        target_text = f"<ir> {item['c_ir']} </ir>"
        
        # Tokenize with attention masks
        source_encoded = self.tokenizer(
            source_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        target_encoded = self.tokenizer(
            target_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        return {
            'input_ids': source_encoded['input_ids'].squeeze(),
            'attention_mask': source_encoded['attention_mask'].squeeze(),
            'labels': target_encoded['input_ids'].squeeze(),
            'decoder_attention_mask': target_encoded['attention_mask'].squeeze()
        }

class CodeT5Trainer:
    def __init__(
        self,
        model_name: str = "Salesforce/codet5-base",
        max_length: int = 512,  # Reduced from 512
        batch_size: int = 16,    # Reduced from 8
        gradient_accumulation_steps: int = 4,
        learning_rate: float = 2e-5,
        weight_decay: float = 0.01,
    ):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.max_length = max_length
        self.batch_size = batch_size
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        
        # Initialize tokenizer
        self.tokenizer = RobertaTokenizer.from_pretrained(model_name)
        
        # Add special tokens
        special_tokens = {
            'additional_special_tokens': [
                '<func>', '</func>', '<ir>', '</ir>'
            ]
        }
        self.tokenizer.add_special_tokens(special_tokens)
        
        # Initialize model
        self.model = T5ForConditionalGeneration.from_pretrained(model_name)
        #self.config.max_position_embeddings = 1024
        self.model.resize_token_embeddings(len(self.tokenizer))
         
        # Enable gradient checkpointing for memory efficiency
        self.model.gradient_checkpointing_enable()
        self.model.to(self.device)

    def load_data(self, json_path: str, test_size: float = 0.1):
        """Load and split data"""
        with open(json_path, 'r') as f:
            data = json.load(f)
            
        # Clean and preprocess data
        cleaned_data = []
        for item in data:
            if 'c_code' in item and 'c_ir' in item:
                cleaned_code = ' '.join(item['c_code'].split())
                cleaned_ir = ' '.join(item['c_ir'].split())
                if cleaned_code and cleaned_ir:  # Ensure non-empty
                    cleaned_data.append({
                        'c_code': cleaned_code,
                        'c_ir': cleaned_ir
                    })
        
        # Create dataset and split
        dataset = Dataset.from_list(cleaned_data)
        split_dataset = dataset.train_test_split(test_size=test_size, seed=42)
        
        # Create dataloaders
        train_dataset = CodeTranslationDataset(
            split_dataset['train'], self.tokenizer, self.max_length
        )
        val_dataset = CodeTranslationDataset(
            split_dataset['test'], self.tokenizer, self.max_length
        )
        
        self.train_dataloader = DataLoader(
            train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=4
        )
        self.val_dataloader = DataLoader(
            val_dataset,
            batch_size=self.batch_size,
            num_workers=4
        )

    def train(self, num_epochs: int = 10, save_path: str = "codet5_ir_model"):
        """Train the model with memory optimizations"""
        # Initialize optimizer with weight decay
        no_decay = ['bias', 'LayerNorm.weight']
        optimizer_grouped_parameters = [
            {
                'params': [p for n, p in self.model.named_parameters() 
                        if not any(nd in n for nd in no_decay)],
                'weight_decay': self.weight_decay
            },
            {
                'params': [p for n, p in self.model.named_parameters() 
                        if any(nd in n for nd in no_decay)],
                'weight_decay': 0.0
            }
        ]
        optimizer = torch.optim.AdamW(optimizer_grouped_parameters, lr=self.learning_rate)
        
        best_val_loss = float('inf')
        early_stopping_counter = 0
        patience = 3
        
        for epoch in range(num_epochs):
            self.model.train()
            total_loss = 0
            optimizer.zero_grad()
            
            train_pbar = tqdm(enumerate(self.train_dataloader), 
                            total=len(self.train_dataloader),
                            desc=f'Epoch {epoch + 1}/{num_epochs}')
            
            for i, batch in train_pbar:
                try:
                    # Move batch to device
                    input_ids = batch['input_ids'].to(self.device)
                    attention_mask = batch['attention_mask'].to(self.device)
                    labels = batch['labels'].to(self.device)
                    
                    # Forward pass
                    outputs = self.model(
                        input_ids=input_ids,
                        attention_mask=attention_mask,
                        labels=labels
                    )
                    
                    # Scale loss for gradient accumulation
                    loss = outputs.loss / self.gradient_accumulation_steps
                    loss.backward()
                    
                    # Update weights with gradient accumulation
                    if (i + 1) % self.gradient_accumulation_steps == 0:
                        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                        optimizer.step()
                        optimizer.zero_grad()
                    
                    total_loss += loss.item() * self.gradient_accumulation_steps
                    train_pbar.set_postfix({'loss': loss.item() * self.gradient_accumulation_steps})
                    
                except RuntimeError as e:
                    if "out of memory" in str(e):
                        if hasattr(torch.cuda, 'empty_cache'):
                            torch.cuda.empty_cache()
                        print(f"WARNING: out of memory on batch {i}. Skipping batch")
                        if hasattr(optimizer, 'zero_grad'):
                            optimizer.zero_grad()
                        continue
                    else:
                        raise e
            
            # Validation phase
            val_loss = self.evaluate()
            print(f"Epoch {epoch + 1}/{num_epochs} - Validation Loss: {val_loss:.4f}")
            
            # Early stopping check
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                early_stopping_counter = 0
                # Save best model
                self.model.save_pretrained(f"{save_path}_best")
                self.tokenizer.save_pretrained(f"{save_path}_best")
            else:
                early_stopping_counter += 1
                if early_stopping_counter >= patience:
                    print("Early stopping triggered")
                    break

    def evaluate(self):
        """Evaluate the model"""
        self.model.eval()
        total_val_loss = 0
        
        with torch.no_grad():
            for batch in tqdm(self.val_dataloader, desc="Validating"):
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                decoder_attention_mask = batch['decoder_attention_mask'].to(self.device)
                
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels,
                    decoder_attention_mask=decoder_attention_mask
                )
                
                total_val_loss += outputs.loss.item()
        
        return total_val_loss / len(self.val_dataloader)

    def generate_ir(self, c_code: str) -> str:
        """Generate IR code from C code"""
        self.model.eval()
        
        # Preprocess input
        source_text = f"<func> {' '.join(c_code.split())} </func>"
        
        # Tokenize
        inputs = self.tokenizer(
            source_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        ).to(self.device)
        
        # Generate with optimal parameters
        with torch.no_grad():
            outputs = self.model.generate(
                input_ids=inputs['input_ids'],
                attention_mask=inputs['attention_mask'],
                max_length=self.max_length,
                num_beams=5,
                length_penalty=1.0,
                no_repeat_ngram_size=2,
                early_stopping=True,
                temperature=0.7,
                top_p=0.95,
                do_sample=True
            )
        
        generated_ir = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return generated_ir.replace('<ir>', '').replace('</ir>', '').strip()

# Usage example
if __name__ == "__main__":
    # Initialize trainer
    trainer = CodeT5Trainer()
    
    # Load and train
    trainer.load_data("cleaned_dataset_c_to_rust_512.json")
    trainer.train(num_epochs=10, save_path="codet5_ir_model")
    
    # Test generation
    test_code = "translate C code to IR code: int add(int a, int b) { return a + b; }"
    generated_ir = trainer.generate_ir(test_code)
    print(f"Generated IR:\n{generated_ir}")
