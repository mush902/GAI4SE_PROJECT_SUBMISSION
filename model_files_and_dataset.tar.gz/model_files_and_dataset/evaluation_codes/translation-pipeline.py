import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

def translate_code(input_text, model_path, max_length=256):
    """
    Translate code using a specified model.
    
    Args:
        input_text (str): Input text for translation
        model_path (str): Path to the pre-trained model
        max_length (int): Maximum length for generated text
    
    Returns:
        str: Translated code
    """
    # Load tokenizer and model
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_path)
    
    # Tokenize the input
    inputs = tokenizer(input_text, return_tensors="pt", truncation=True, padding=True)
    
    # Generate translation
    with torch.no_grad():
        outputs = model.generate(
            inputs["input_ids"], 
            max_length=max_length, 
            num_beams=5, 
            early_stopping=True
        )
    
    # Decode the generated output
    generated_output = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    return generated_output

def translation_pipeline(c_code):
    """
    Perform sequential code translation:
    C Code -> C IR -> Rust IR -> Rust Code
    
    Args:
        c_code (str): Original C code to translate
    
    Returns:
        str: Final Rust code
    """
    # Stage 1: C Code to C IR
    text1 = f"translate C code to IR code: {c_code}"
    c_ir = translate_code(
        text1, 
        model_path="codet5_ir_model_best"
    )
    print("C IR Output:")
    print(c_ir)
    print("\n--- Translation Stage 1 Complete ---\n")
    
    # Stage 2: C IR to Rust IR
    text2 = f"translate C IR to Rust IR: {c_ir}"
    rust_ir = translate_code(
        text2, 
        model_path="ir_translation_model_best"
    )
    print("Rust IR Output:\n")
    print(rust_ir)
    print("\n--- Translation Stage 2 Complete ---\n")
    
    # Stage 3: Rust IR to Rust Code
    text3 = f"translate Rust IR to Rust code: {rust_ir}"
    rust_code = translate_code(
        text3, 
        model_path="rust_ir_translation_model_best"  # Assuming you have this model
    )
    print("Final Rust Code Output:")
    #print(rust_code)
    
    #return rust_code

# Example usage
if __name__ == "__main__":
    #sample_c_code = "int add(int a, int b) { return a + b; }"
    #sample_c_code = "int main(){\n  int n,i;\n  int S[MAX];\n  scanf(\"%d\",&n);\n  for(i=0;i<n;i++){\n    scanf(\"%d\",&S[i]);\n    if(S[i]<0 || S[i]>1000000000){\n      exit(1);\n    }\n  }\n  mergeSort(S,0,n);\n  for(i=0;i<n-1;i++){\n    printf(\"%d \",S[i]);\n  }\n  printf(\"%d\\n\",S[n-1]);\n  printf(\"%d\\n\",count);\n  return 0;\n}"
    #final_rust_code = translation_pipeline(sample_c_code)
    sample_c_code = "int main()\n{\n    int a,b,c,s = 0,cun=0,week=0;\n    scanf(\"%d%d%d\\n\",&a,&b,&c);\n    while (1) {\n        cun++;\n        week++;\n        s+=a;\n        if(week==7){\n            s+=b;\n            week=0;\n        }\n        if(s>=c){\n            printf(\"%d\\n\",cun);\n            break;\n        }\n    }\n    return 0;\n}"
    translation_pipeline(sample_c_code)
