import json
import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import os

def translate_code(input_text, model_path, max_length=256):
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_path)
    
    inputs = tokenizer(input_text, return_tensors="pt", truncation=True, padding=True)
    
    with torch.no_grad():
        outputs = model.generate(
            inputs["input_ids"], 
            max_length=max_length, 
            num_beams=5, 
            early_stopping=True
        )
    
    generated_output = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    return generated_output

def translation_pipeline(c_code):
    # Stage 1: C Code to C IR
    print("Stage 1 started \n")
    text1 = f"translate C code to IR code: {c_code}"
    c_ir = translate_code(
        text1, 
        model_path="codet5_ir_model_best",
        max_length= 1024
    )
    print("Stage 1 complete \n")
    # Stage 2: C IR to Rust IR
    text2 = f"translate C IR to Rust IR: {c_ir}"
    rust_ir = translate_code(
        text2, 
        model_path="ir_translation_model_best",
        max_length= 2048
    )
    print("Stage 2 complete \n")
    return c_ir, rust_ir
    
    # Stage 3: Rust IR to Rust Code
    # text3 = f"translate Rust IR to Rust code: {rust_ir}"
    # rust_code = translate_code(
    #     text3, 
    #     model_path="ir_to_rust_code_model"
    #     max_length= 2048
    # )
    
    #return rust_code

def process_translation_batch(input_json_path, output_json_c_ir, output_json_rust_ir, output_json_rust_code):
    with open(input_json_path, 'r') as f:
        c_codes = json.load(f)
    
    inference_rust_codes = []
    inference_c_ir_codes = []
    inference_rust_ir_codes = []
    for i, c_code in enumerate(c_codes):
        print(f"Processing entry {i+1}/{len(c_codes)}")
        try:
            c_ir, rust_ir = translation_pipeline(c_code)
            inference_c_ir_codes.append(c_ir)
            inference_rust_ir_codes.append(rust_ir)
            #inference_rust_codes.append(rust_code)
        except Exception as e:
            print(f"Error processing entry {i+1}: {e}")
            #inference_rust_codes.append(None)
            inference_c_ir_codes.append(None)
            inference_rust_ir_codes.append(None)
    
    # with open(output_json_rust_code, 'w') as f:
    #     json.dump(inference_rust_codes, f, indent=2)
    with open(output_json_c_ir, 'w') as f:
        json.dump(inference_c_ir_codes, f, indent=2)
    
    with open(output_json_rust_ir, 'w') as f:
        json.dump(inference_rust_ir_codes, f, indent=2)

    print(f"Translation complete. Results saved to {output_json_c_ir}")
    print(f"Translation complete. Results saved to {output_json_rust_ir}")
    #print(f"Translation complete. Results saved to {output_json_rust_code}")

# Main execution
if __name__ == "__main__":
    process_translation_batch(
        input_json_path='random_c_codes.json',
        output_json_c_ir='inference_c_ir.json',
        output_json_rust_ir='inference_rust_ir.json',
        output_json_rust_code='inference_rust_code.json'
    )
