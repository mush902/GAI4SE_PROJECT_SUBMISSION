import json
import random

def select_random_entries(input_file, output_c_file, output_rust_file, output_rust_ir_file, output_c_ir_file, num_entries=20):
    with open(input_file, 'r') as f:
        data = json.load(f)

    num_entries = min(num_entries, len(data))
    random_entries = random.sample(data, num_entries)

    c_codes = [entry["c_code"] for entry in random_entries]
    rust_codes = [entry["rust_code"] for entry in random_entries]
    rust_irs = [entry["rust_ir"] for entry in random_entries]
    c_irs = [entry["c_ir"] for entry in random_entries]
    with open(output_c_file, 'w') as f:
        json.dump(c_codes, f, indent=2)

    with open(output_rust_file, 'w') as f:
        json.dump(rust_codes, f, indent=2)
    
    with open(output_rust_ir_file, 'w') as f:
        json.dump(rust_irs, f, indent=2)
    
    with open(output_c_ir_file, 'w') as f:
        json.dump(c_irs, f, indent=2)
    print(f"Selected {num_entries} random entries.")

# Example usage
select_random_entries(
    input_file='cleaned_10K_dataset_2048.json', 
    output_c_file='random_c_codes.json', 
    output_rust_file='random_rust_codes.json',
    output_rust_ir_file='random_rust_ir.json',
    output_c_ir_file='random_c_ir.json'
)
