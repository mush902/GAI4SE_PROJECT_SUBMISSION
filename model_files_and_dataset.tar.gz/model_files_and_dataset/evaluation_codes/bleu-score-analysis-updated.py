import json
from nltk.translate.bleu_score import corpus_bleu, SmoothingFunction

def calculate_bleu_score(reference_file, hypothesis_file):
    with open(reference_file, 'r') as f:
        references = json.load(f)
    with open(hypothesis_file, 'r') as f:
        hypotheses = json.load(f)

    # Tokenize references and hypotheses
    tokenized_references = [[line.split()] for line in references]
    tokenized_hypotheses = [line.split() for line in hypotheses]

    # Calculate BLEU score
    bleu_score = corpus_bleu(tokenized_references, tokenized_hypotheses, 
                            smoothing_function=SmoothingFunction().method1)

    # Individual n-gram BLEU scores
    bleu_1 = corpus_bleu(tokenized_references, tokenized_hypotheses, 
                        weights=(1, 0, 0, 0), 
                        smoothing_function=SmoothingFunction().method1)
    bleu_2 = corpus_bleu(tokenized_references, tokenized_hypotheses, 
                        weights=(0.5, 0.5, 0, 0), 
                        smoothing_function=SmoothingFunction().method1)
    bleu_4 = corpus_bleu(tokenized_references, tokenized_hypotheses, 
                        weights=(0.25, 0.25, 0.25, 0.25), 
                        smoothing_function=SmoothingFunction().method1)

    results = {
        'BLEU-1': bleu_1 * 100,
        'BLEU-2': bleu_2 * 100, 
        'BLEU-4': bleu_4 * 100,
        'BLEU-overall': bleu_score * 100
    }

    return results

# Example usage
bleu_scores = calculate_bleu_score(
    reference_file='random_rust_ir.json',
    hypothesis_file='inference_rust_ir.json'
)

for metric, score in bleu_scores.items():
    print(f"{metric}: {score:.2f}")
