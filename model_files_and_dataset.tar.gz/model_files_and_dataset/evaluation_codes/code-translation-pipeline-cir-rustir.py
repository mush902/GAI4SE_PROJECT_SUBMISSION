import json
import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
import os


def translate_code(input_text, model_path, max_length=2048):
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_path)
    
    inputs = tokenizer(input_text, return_tensors="pt", truncation=True, padding=True)
    
    with torch.no_grad():
        outputs = model.generate(
            inputs["input_ids"], 
            max_length=max_length, 
            num_beams=5, 
            early_stopping=True
        )
    
    generated_output = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    return generated_output


def translation_pipeline(c_ir):
    # Stage 1: C Code to C IR
    
    # Stage 3: Rust IR to Rust Code
    print("Start stage \n")
    text2 = f"translate C IR to Rust Ir: {c_ir}"
    rust_code = translate_code(
        text2, 
        model_path="ir_translation_model_best"
    )
    print("End stage \n")
    return rust_code


def process_translation_batch(input_json_path, output_json_path):
    # Read random C codes
    with open(input_json_path, 'r') as f:
        c_irs = json.load(f)
    
    # Translate each C code
    inference_rust_irs = []
    for i, c_ir in enumerate(c_irs):
        print(f"Processing entry {i+1}/{len(c_irs)}")
        try:
            rust_ir = translation_pipeline(c_ir)
            inference_rust_irs.append(rust_ir)
        except Exception as e:
            print(f"Error processing entry {i+1}: {e}")
            inference_rust_irs.append(None)
    
    # Save translated Rust codes
    with open(output_json_path, 'w') as f:
        json.dump(inference_rust_irs, f, indent=2)
    
    print(f"Translation complete. Results saved to {output_json_path}")


if __name__ == "__main__":
    process_translation_batch(
        input_json_path='random_c_ir.json',
        output_json_path='inference_rust_ir.json'
    )
